package com.service.serveigo;

public class ClassUser {

    String name;
    String address;
    String altEmail;
    String contact;
    String imageUrl;

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getAltEmail() {
        return altEmail;
    }

    public String getContact() {
        return contact;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
