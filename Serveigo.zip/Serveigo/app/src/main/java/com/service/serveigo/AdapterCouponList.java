package com.service.serveigo;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterCouponList extends RecyclerView.Adapter<AdapterCouponList.PostViewHolder>{
    private ArrayList<ClassCoupon> items;
    private Context context;

    public AdapterCouponList(ArrayList<ClassCoupon> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public AdapterCouponList.PostViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.coupon_cardview,parent,false);
        return new AdapterCouponList.PostViewHolder(view);
    }


    @Override
    public void onBindViewHolder(final AdapterCouponList.PostViewHolder holder, int position) {
        final ClassCoupon item=items.get(position);

        holder.textView1.setText(item.getHead());
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent("custom-message");
                intent.putExtra("item", item.getValue());
                LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return items.size();
    }

    public class PostViewHolder extends RecyclerView.ViewHolder {

        public TextView textView1;
        public TextView button;

        public PostViewHolder(View itemView) {
            super(itemView);

            textView1=itemView.findViewById(R.id.textView);
            button=itemView.findViewById(R.id.button);
        }
    }
}
