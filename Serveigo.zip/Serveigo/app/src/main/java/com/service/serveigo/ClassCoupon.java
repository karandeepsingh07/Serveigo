package com.service.serveigo;

public class ClassCoupon {

    int maxDiscount;
    int minValue;
    int percentage;
    int value;
    int Index;
    int Head;

    public int getMaxDiscount() {
        return maxDiscount;
    }

    public int getMinValue() {
        return minValue;
    }

    public int getPercentage() {
        return percentage;
    }

    public int getValue() {
        return value;
    }

    public int getIndex() {
        return Index;
    }

    public int getHead() {
        return Head;
    }
}
