package com.service.serveigo;

public class ClassCategory {
    String Head;
    String ImageUrl;
    String uid;

    public String getHead() {
        return Head;
    }

    public String getImageUrl() {
        return ImageUrl;
    }

    public String getUid() {
        return uid;
    }
}
