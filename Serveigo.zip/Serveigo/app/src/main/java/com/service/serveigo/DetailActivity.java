package com.service.serveigo;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

public class DetailActivity extends AppCompatActivity {

    FirebaseFirestore firebaseFirestore;
    private int mYear, mMonth, mDay, mHour, mMinute,day1,month1,year1;
    TextView textViewDate, textViewTime,textViewVendorName,textViewVendorType;
    Button buttonBookDetail,buttonInstant,buttonNormal,buttonBack;
    ImageView buttonCall,imageViewVendor;
    EditText editTextComment,editTextAddress;
    ProgressBar progressBar;
    String userName;
    boolean buttonCheck=true;
    LinearLayout linearLayoutCall;
    int REQUEST_PHONE_CALL=1;
    StringBuilder timestamp;
    ArrayList<String> serviceList,priceList;
    ArrayList<ClassService> listService;
    ArrayList<ClassCoupon> listCoupon;
    AdapterServiceFinal adapterServiceFinal;
    AdapterCouponList adapterCouponList;
    RecyclerView recyclerView;
    float totalBill;
    float totalBillAfterDiscount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView textViewToolbar=toolbar.findViewById(R.id.textView_location);
        textViewToolbar.setText("Booking Details");

        Intent intent=getIntent();
        final String state= intent.getStringExtra("state");
        final String city= intent.getStringExtra("city");
        final String category= intent.getStringExtra("category");
        final String subCategory= intent.getStringExtra("subCategory");
        final String vendorID= intent.getStringExtra("vendorID");
        final String vendorAddress= intent.getStringExtra("vendorAddress");
        final String vendorName= intent.getStringExtra("vendorName");
        final String services= intent.getStringExtra("services");
        final String vendorImage=intent.getStringExtra("vendorImage");
        serviceList = (ArrayList<String>) intent.getSerializableExtra("serviceList");
        priceList = (ArrayList<String>) intent.getSerializableExtra("priceList");

        for(int i=0;i<serviceList.size();i++){
            ClassService service=new ClassService();
            service.name=serviceList.get(i);
            service.price=priceList.get(i);
            totalBill+=Integer.parseInt(service.price);
            listService.add(service);
        }

        textViewDate= findViewById(R.id.textView_date);
        textViewTime= findViewById(R.id.textView_time);
        textViewVendorType=findViewById(R.id.textView_vendorType);
        imageViewVendor=findViewById(R.id.imageView_detail);
        linearLayoutCall=findViewById(R.id.linearLayout_call);
        editTextComment = findViewById(R.id.editText_comment);
        editTextAddress = findViewById(R.id.editText_address);
        buttonBookDetail= findViewById(R.id.button_book_detail);
        buttonInstant=findViewById(R.id.button_instantService);
        buttonNormal=findViewById(R.id.button_normalService);
        buttonCall= findViewById(R.id.buttonCall);
        textViewVendorName= findViewById(R.id.textView_vendorName);
        progressBar= findViewById(R.id.progressBar);
        adapterServiceFinal=new AdapterServiceFinal(listService,this);
        adapterCouponList=new AdapterCouponList(listCoupon,this);
        recyclerView=findViewById(R.id.recyclerViewService);

        firebaseFirestore= FirebaseFirestore.getInstance();
        Log.d("xyz1",vendorID);
        buttonBack=toolbar.findViewById(R.id.button_back);

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        buttonInstant.setPadding(60,60,60,60);
        buttonNormal.setPadding(10,0,10,0);
        buttonInstant.setBackgroundResource(R.drawable.round_button_orange);
        buttonNormal.setBackgroundResource(R.drawable.round_edittext_grey);
        buttonNormal.setTextColor(Color.BLACK);
        buttonInstant.setTextColor(Color.WHITE);
        textViewDate.setVisibility(View.GONE);
        textViewTime.setVisibility(View.GONE);
        buttonCheck=true;

        String[] nameList=vendorName.split(" ");
        String name=nameList[0];
        textViewVendorName.setText(name);
        textViewVendorType.setText(subCategory);
        Picasso.get().load(vendorImage).placeholder(R.drawable.plumbing)
                .error(R.drawable.plumbing).into(imageViewVendor);
        getResult(state,city,category,subCategory);

        final Calendar c = Calendar.getInstance();
        DateFormat date = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat time = new SimpleDateFormat("HH:mm a");
        final String localDate = date.format(c.getTime());
        final String localTime = time.format(c.getTime());
        textViewDate.setText(localDate);
        textViewTime.setText(localTime);

        recyclerView.setAdapter(adapterServiceFinal);
        adapterServiceFinal.notifyDataSetChanged();

        buttonInstant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonInstant.setPadding(60,60,60,60);
                buttonNormal.setPadding(10,0,10,0);
                buttonInstant.setBackgroundResource(R.drawable.round_button_orange);
                buttonNormal.setBackgroundResource(R.drawable.round_edittext_grey);
                buttonInstant.setTextColor(Color.WHITE);
                buttonNormal.setTextColor(Color.BLACK);
                textViewDate.setVisibility(View.GONE);
                textViewTime.setVisibility(View.GONE);
                textViewDate.setText(localDate);
                textViewTime.setText(localTime);
                buttonCheck=true;
            }
        });
        buttonNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonNormal.setPadding(60,60,60,60);
                buttonInstant.setPadding(10,0,10,0);
                buttonNormal.setBackgroundResource(R.drawable.round_button_orange);
                buttonInstant.setBackgroundResource(R.drawable.round_edittext_grey);
                buttonInstant.setTextColor(Color.BLACK);
                buttonNormal.setTextColor(Color.WHITE);
                textViewDate.setVisibility(View.VISIBLE);
                textViewTime.setVisibility(View.VISIBLE);
                textViewDate.setHint("Select Date");
                textViewTime.setHint("Select Time");
                buttonCheck=false;
            }
        });

        linearLayoutCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(DetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(DetailActivity.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_PHONE_CALL);
                }
                else
                {
                    progressBar.setVisibility(View.VISIBLE);
                    firebaseFirestore.collection("Admin").document("Contact").get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        String number= task.getResult().get("number").toString();
                        //Picasso.get().load(url).into(imageViewQR);
                        progressBar.setVisibility(View.GONE);
                        if (ContextCompat.checkSelfPermission(DetailActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(DetailActivity.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_PHONE_CALL);
                        }
                        else
                        {
                            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
                            startActivity(intent);
                        }
                    }
                });
                }
            }
        });

        buttonBookDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(detailCheck()) {
                    progressBar.setVisibility(View.VISIBLE);
                    buttonBookDetail.setEnabled(false);
                    Map<String, Object> job = new HashMap<>();
                    job.put("vendorID", vendorID);
                    job.put("vendorAddress", vendorAddress);
                    job.put("UserId", FirebaseAuth.getInstance().getCurrentUser().getUid());
                    if (buttonCheck) {
                        job.put("date", textViewDate.getText().toString());
                        job.put("instant", true);
                    } else {
                        job.put("date", textViewDate.getText().toString());
                        job.put("instant", false);
                    }
                    job.put("payment",false);
                    job.put("time", textViewTime.getText().toString());
                    job.put("services", services);
                    job.put("userAddress", editTextAddress.getText().toString());
                    job.put("status", "Open");
                    job.put("userName", userName);
                    job.put("comments", editTextComment.getText().toString());
                    job.put("vendorName", textViewVendorName.getText().toString());
                    job.put("vendorType", subCategory);

                    firebaseFirestore.collection("Job").document("Open").collection("UID")
                            .add(job)
                            .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                @Override
                                public void onSuccess(DocumentReference documentReference) {
                                    Log.d("xyz", "DocumentSnapshot added with ID: " + documentReference.getId());
                                    String status = "Open";
                                    Map<String, Object> jobId = new HashMap<>();
                                    jobId.put("jobId", documentReference.getId());
                                    jobId.put("status", status);
                                    jobId.put("date", textViewDate.getText().toString());
                                    String id = documentReference.getId();
                                    firebaseFirestore.collection("Area").document(state).collection(city).document(category).collection("List").document(subCategory).collection("Vendor").document("" + vendorID).collection("Job").document(documentReference.getId()).set(jobId);
                                    firebaseFirestore.collection("Users").document(FirebaseAuth.getInstance().getCurrentUser().getUid()).collection("Booking").document(documentReference.getId()).set(jobId);
                                    Intent intent1 = new Intent(DetailActivity.this, ThankYouActivity.class);
                                    startActivity(intent1);
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w("xyz", "Error adding document", e);
                                }
                            });
                }
            }
        });
        showPromoCode();
    }

    private void getResult(final String state,final String city,final String category,final String subCategory){
        firebaseFirestore.collection("Users").document(FirebaseAuth.getInstance().getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        userName= document.getString("name");
                        editTextAddress.setText(document.getString("address"));
                    } else {
                        Log.d("xyz", "No such document");
                    }
                } else {
                    Log.d("xyz", "get failed with ", task.getException());
                }
            }
        });
    }

    private void showPromoCode(){
        firebaseFirestore.collection("Coupons").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    for(DocumentSnapshot snapshot: task.getResult()){
                        ClassCoupon classCoupon=snapshot.toObject(ClassCoupon.class);
                        listCoupon.add(classCoupon);
                        adapterCouponList.notifyDataSetChanged();
                    }
                }
            }
        });
    }

    public void datePick(final View v){
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        textViewDate.setText(dayOfMonth+"/"+(monthOfYear+1)+"/"+year);
                        timestamp.append(year+"/"+(monthOfYear+1)+"/"+dayOfMonth+" ");
                        day1=dayOfMonth;
                        month1=monthOfYear+1;
                        Log.d("getCurrentDateTime", String.valueOf(day1));
                        Log.d("getCurrentDateTime", String.valueOf(month1));
                        timePick(v);
                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }
    public void timePick(View v){
        final Calendar c = Calendar.getInstance();
        // Launch Time Picker Dialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
                        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd");
                        String getCurrentDateTime = sdf.format(c.getTime());
                        String getCurrentDate = sdf2.format(c.getTime());
                        String minuteLocal= String.valueOf(minute);
                        String hourLocal= String.valueOf(hourOfDay);
                        String dayLocal= String.valueOf(day1);
                        Log.d("getCurrentDateTime", String.valueOf(day1));
                        String monthLocal= String.valueOf(month1);
                        if (minute < 10)
                            minuteLocal = "0" + minute;
                        if (hourOfDay < 10)
                            hourLocal = "0" + hourOfDay;
                        if ((mMonth+1) < 10)
                            monthLocal = "0" + month1;
                        if (mDay < 10)
                            dayLocal = "0" + day1;
                        String getMyTime=mYear+"/"+monthLocal+"/"+dayLocal+" "+hourLocal+":"+minuteLocal;
                        String getMyDate=mYear+"/"+monthLocal+"/"+dayLocal;
                        Log.d("getCurrentDateTime",getCurrentDateTime);
                        Log.d("getCurrentDateTime",getMyTime);

                        if(getCurrentDate.compareTo(getMyDate)<0) {
                            updateTime(hourOfDay,minute);
                        }else if (getCurrentDateTime.compareTo(getMyTime) < 0){
                            updateTime(hourOfDay,minute);
                        }
                        else
                        {
                            Toast.makeText(DetailActivity.this, "Select correct date and time", Toast.LENGTH_SHORT).show();
                            textViewDate.setText("Select Date");
                            textViewTime.setText("Select Time");
                        }
                        /*SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                        Date selDate= null;
                        try {
                            selDate = sdf.parse(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        if(System.currentTimeMillis() < selDate.getTime())
                            textViewDate.setText("Select Date");
                        else
                            Toast.makeText(DetailActivity.this, "Select date equal to or greater than today's date", Toast.LENGTH_SHORT).show();*/
                    }
                }, mHour, mMinute, true);
        timePickerDialog.show();
    }
    private void updateTime(int hours, int mins) {

        String timeSet = "";
        if (hours > 12) {
            hours -= 12;
            timeSet = "PM";
        } else if (hours == 0) {
            hours += 12;
            timeSet = "AM";
        } else if (hours == 12)
            timeSet = "PM";
        else
            timeSet = "AM";


        String minutes = "";
        if (mins < 10)
            minutes = "0" + mins;
        else
            minutes = String.valueOf(mins);

        String aTime = new StringBuilder().append(hours).append(':')
                .append(minutes).append(" ").append(timeSet).toString();

        textViewTime.setText(aTime);
        timestamp.append(aTime);
    }
    public boolean detailCheck(){
        if(TextUtils.isEmpty(editTextAddress.getText().toString().trim())){
            editTextAddress.setError("Enter full address");
            editTextComment.setHint("Enter Address");
            return false;
        }/*if(TextUtils.isEmpty(editTextComment.getText().toString().trim())){
            editTextComment.setError("Describe the issue");
            editTextComment.setHint("Comment");
            return false;
        }*/if(textViewDate.getText().toString().equals("Select Date") && !buttonCheck){
            Toast.makeText(this, "Enter Date", Toast.LENGTH_SHORT).show();
            return false;
        }if(textViewTime.getText().toString().equals("Select Time") && !buttonCheck){
            Toast.makeText(this, "Enter Time", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            float discount=0;
            int discountValue=intent.getIntExtra("item",0);
            if(discountValue!=0) {
                discount = ((totalBill / 100.0f) * discountValue);
            }
            totalBillAfterDiscount = totalBill-discount;
            totalBill= totalBillAfterDiscount/discountValue;
            Log.d("xyzCoupon", String.valueOf(discountValue));
        }
    };
}