package com.service.serveigo;

public class ClassSubCategory {

    String Category;
    String ImageUrl;
    String Head;
    String uid;
    String Banner;

    public String getCategory() {
        return Category;
    }

    public String getHead() {
        return Head;
    }

    public String getImageUrl() {
        return ImageUrl;
    }

    public String getUid() {
        return uid;
    }

    public String getBanner() {
        return Banner;
    }
}
