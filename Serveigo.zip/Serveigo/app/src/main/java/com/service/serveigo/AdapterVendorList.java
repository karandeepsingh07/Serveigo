package com.service.serveigo;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterVendorList extends RecyclerView.Adapter<AdapterVendorList.PostViewHolder> {

    private ArrayList<ClassVendor> items;
    private Context context;
    private String state;
    private String city;
    private String category;
    private String subCategory;
    private StringBuilder services;
    private ArrayList<String> serviceList;
    private ArrayList<String> priceList;

    public AdapterVendorList(ArrayList<ClassVendor> items, Context context, String state, String city, String category, String subCategory, StringBuilder services, ArrayList<String> serviceList, ArrayList<String> priceList) {
        this.items = items;
        this.context = context;
        this.state = state;
        this.city = city;
        this.category = category;
        this.subCategory = subCategory;
        this.services = services;
        this.serviceList = serviceList;
        this.priceList = priceList;
    }

    @NonNull
    @Override
    public AdapterVendorList.PostViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if(viewType==0) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.vendor_cardviewsecond, parent, false);
            return new AdapterVendorList.PostViewHolder(view);
        }else{
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.vendor_cardview, parent, false);
            return new AdapterVendorList.PostViewHolder(view);
        }
    }


    @Override
    public void onBindViewHolder(AdapterVendorList.PostViewHolder holder, int position) {

        final ClassVendor item =items.get(position);
        final String vendorID=item.getVendorID();
        final String vendorAddress=item.getAddress();
        final String vendorName=item.getName();
        holder.textView1.setText(vendorName);
      //  holder.textView2.setText(item.getSubHead());
        Picasso.get().load(item.getVendorImage()).into(holder.imageView);


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  DataSnapshot dataSnapshot;
                //String matchId = dataSnapshot.getChildren().iterator().next().getKey().toString();
                // Toast.makeText(context, matchId, Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(context,DetailActivity.class);

                intent.putExtra("state",state);
                intent.putExtra("city",city);
                intent.putExtra("category",category);
                intent.putExtra("subCategory",subCategory);
                intent.putExtra("vendorID",vendorID);
                intent.putExtra("vendorAddress",vendorAddress);
                intent.putExtra("vendorName",vendorName);
                intent.putExtra("services",services.toString());
                intent.putExtra("vendorImage",item.getVendorImage());
                intent.putExtra("serviceList",serviceList);
                intent.putExtra("priceList",priceList);
                context.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemViewType(int position) {
        // Just as an example, return 0 or 2 depending on position
        // Note that unlike in ListView adapters, types don't have to be contiguous
        return position % 2;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class PostViewHolder extends RecyclerView.ViewHolder {

        public TextView textView1;
        public TextView textView2;
        ImageView imageView;

        public PostViewHolder(View itemView) {
            super(itemView);

            textView1=itemView.findViewById(R.id.textView_vendorName);
          //  textView2=itemView.findViewById(R.id.textViewSubHead);
            imageView=itemView.findViewById(R.id.imageView);


        }
    }
}
