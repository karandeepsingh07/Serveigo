package com.service.serveigo;

public class ClassService {

    public String name;
    public boolean checked;
    public String price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public String getPrice() {
        return price;
    }
}
