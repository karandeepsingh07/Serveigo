package com.service.serveigo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class BookingActivity extends AppCompatActivity {

    FirebaseFirestore firebaseFirestore;
    int REQUEST_PHONE_CALL=1;
    FirebaseUser firebaseUser;
    EditText editTextAmount;
    Button buttonAccept,buttonBack,buttonSupport;
    ProgressBar progressBar,progressBar2;
    TextView textViewOrder,textViewPayment,textViewJob,textViewComment,textViewVendorName,textViewVendorType;
    String state,city,category,subCategory,vendorID,jobID,vendorImage,amount;
    LinearLayout linearLayoutDummy;
    ImageView imageViewDetail;
    TextView textViewAmount;
    final int UPI_PAYMENT = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        TextView textViewToolbar=toolbar.findViewById(R.id.textView_location);
        textViewToolbar.setText("Booking Detail");

        Intent intent=getIntent();
        jobID=intent.getStringExtra("jobId");
        vendorImage=intent.getStringExtra("vendorImage");

        textViewVendorName=findViewById(R.id.textView_vendorName);
        textViewVendorType=findViewById(R.id.textView_vendorType);
        textViewComment=findViewById(R.id.textView_comment);
        textViewJob=findViewById(R.id.textView_job);
        textViewPayment=findViewById(R.id.textView_payment);
        textViewOrder=findViewById(R.id.textView_order);
        textViewAmount=findViewById(R.id.textView_amount);
        buttonAccept=findViewById(R.id.button_accept);
        editTextAmount = findViewById(R.id.editText_amount);
        linearLayoutDummy=findViewById(R.id.linearLayout_dummy);
        progressBar=findViewById(R.id.progressBar);
        progressBar2=findViewById(R.id.progressBar2);
        firebaseFirestore= FirebaseFirestore.getInstance();
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        buttonBack=toolbar.findViewById(R.id.button_back);
        buttonSupport=findViewById(R.id.buttonSupport);
        imageViewDetail=findViewById(R.id.imageView_detail);

        Picasso.get().load(vendorImage).placeholder(R.drawable.plumbing)
                .error(R.drawable.plumbing).into(imageViewDetail);

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        buttonSupport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(BookingActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(BookingActivity.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_PHONE_CALL);
                }
                else
                {
                    progressBar.setVisibility(View.VISIBLE);
                    firebaseFirestore.collection("Admin").document("Contact").get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                            String number= task.getResult().get("number").toString();
                            //Picasso.get().load(url).into(imageViewQR);
                            progressBar.setVisibility(View.GONE);
                            if (ContextCompat.checkSelfPermission(BookingActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(BookingActivity.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_PHONE_CALL);
                            }
                            else
                            {
                                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
                                startActivity(intent);
                            }
                        }
                    });
                }
            }
        });

        buttonAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //progressBar2.setVisibility(View.VISIBLE);
                //buttonAccept.setVisibility(View.GONE);
                String amount = editTextAmount.getText().toString();
                String note="Payment";
                String upiId="8305046502@ybl";
                String name="Yogesh Kumar Sahu";
                payUsingUpi(amount, upiId, name, note);
            }
        });
       /* for(int i=0;i<5;i++){
            ClassCategory score=new ClassCategory();
            score.head="cg";
            score.subHead="pnb";
            listItems.add(score);
            adapter.notifyDataSetChanged();
        }*/
       getResult();
    }

    private void getResult(){
        firebaseFirestore.collection("Users").document(firebaseUser.getUid()).collection("Booking").document(jobID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                            final String status= task.getResult().getString("status");
                            if(status.equals("DuePayment")){
                                textViewOrder.setText("Accepted");
                                textViewOrder.setTextColor(Color.BLACK);
                                textViewOrder.setBackgroundColor(Color.GREEN);
                                textViewPayment.setText("Pending");
                                textViewPayment.setTextColor(Color.WHITE);
                                textViewPayment.setBackgroundColor(Color.RED);
                                textViewJob.setText("Processing");
                                textViewJob.setTextColor(Color.WHITE);
                                textViewJob.setBackgroundColor(Color.GRAY);
                            }
                            if(status.equals("Rejected")){
                                textViewOrder.setText("Rejected");
                                textViewOrder.setBackgroundColor(Color.RED);
                            }
                            if(status.equals("Closed")){
                                textViewOrder.setText("Accepted");
                                textViewOrder.setTextColor(Color.BLACK);
                                textViewOrder.setBackgroundColor(Color.GREEN);
                                textViewPayment.setText("Done");
                                textViewPayment.setBackgroundColor(Color.GREEN);
                                textViewJob.setText("Done");
                                textViewJob.setBackgroundColor(Color.GREEN);
                            }
                            firebaseFirestore.collection("Job").document(status).collection("UID").document(task.getResult().getId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    ClassBooking classBooking= task.getResult().toObject(ClassBooking.class);
                                    vendorID=classBooking.getVendorID();
                                    String[] nameList=classBooking.getVendorName().split(" ");
                                    String name=nameList[0];
                                    textViewVendorName.setText(name);
                                    textViewVendorType.setText(classBooking.getVendorType());
                                    textViewComment.setText(classBooking.getComments());
                                    amount=task.getResult().getString("amount");
                                    textViewAmount.setText(amount);
                                    Log.d("xyz", task.getResult().toString());
                                    firebaseFirestore.collection("Vendor").document(vendorID).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                            state= task.getResult().getString("state");
                                            city=task.getResult().getString("city");
                                            category=task.getResult().getString("category");
                                            subCategory=task.getResult().getString("subCategory");
                                            progressBar.setVisibility(View.GONE);
                                            if(status.equals("DuePayment")){
                                                linearLayoutDummy.setVisibility(View.VISIBLE);
                                            }else if(status.equals("Closed")){
                                                linearLayoutDummy.setVisibility(View.VISIBLE);
                                                editTextAmount.setVisibility(View.GONE);
                                                textViewAmount.setVisibility(View.VISIBLE);
                                                buttonAccept.setVisibility(View.GONE);
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    else {
                        Log.w("xyz", "Error getting documents.", task.getException());
                    }
            }
        });
    }

    public void moveFirestoreDocument(final DocumentReference fromPath, final DocumentReference toPath,final String state,final String city,final String category,final String subCategory,final String vendorID,final String jobID) {
        fromPath.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null) {
                        toPath.set(document.getData())
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Log.d("xyz", "DocumentSnapshot successfully written!");
                                        fromPath.delete()
                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {
                                                        Log.d("xyz", "DocumentSnapshot successfully deleted!");
                                                        firebaseFirestore.collection("Job").document("Closed").collection("UID").document(jobID).update("status","Closed","uid",jobID).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                firebaseFirestore.collection("Users").document(firebaseUser.getUid()).collection("Booking").document(jobID).update("status","Closed").addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        firebaseFirestore.collection("Area").document(state).collection(city).document(category).collection("List").document(subCategory).collection("Vendor").document(vendorID).collection("Job").document(jobID).update("status","Closed").addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                            @Override
                                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                                Log.d("xyz", "Done Update!");
                                                                                Intent intent = new Intent(BookingActivity.this, HomeActivity.class);
                                                                                Toast.makeText(BookingActivity.this, "Payment Done from your side", Toast.LENGTH_SHORT).show();
                                                                                startActivity(intent);
                                                                                finish();
                                                                            }
                                                                        });
                                                                    }
                                                                });
                                                            }
                                                        });
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        Log.w("xyz", "Error deleting document", e);
                                                    }
                                                });
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.w("xyz", "Error writing document", e);
                                    }
                                });
                    } else {
                        Log.d("xyz", "No such document");
                    }
                } else {
                    Log.d("xyz", "get failed with ", task.getException());
                }
            }
        });
    }

    void payUsingUpi(String amount, String upiId, String name, String note) {

        Uri uri = Uri.parse("upi://pay").buildUpon()
                .appendQueryParameter("pa", upiId)
                .appendQueryParameter("pn", name)
                .appendQueryParameter("tn", note)
                .appendQueryParameter("am", amount)
                .appendQueryParameter("cu", "INR")
                .build();


        Intent upiPayIntent = new Intent(Intent.ACTION_VIEW);
        upiPayIntent.setData(uri);

        // will always show a dialog to user to choose an app
        Intent chooser = Intent.createChooser(upiPayIntent, "Pay with");

        // check if intent resolves
        if (null != chooser.resolveActivity(getPackageManager())) {
            startActivityForResult(chooser, UPI_PAYMENT);
        } else {
            Toast.makeText(BookingActivity.this, "No UPI app found, please install one to continue", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case UPI_PAYMENT:
                if ((RESULT_OK == resultCode) || (resultCode == 11)) {
                    if (data != null) {
                        String trxt = data.getStringExtra("response");
                        Log.d("UPI", "onActivityResult: " + trxt);
                        ArrayList<String> dataList = new ArrayList<>();
                        dataList.add(trxt);
                        upiPaymentDataOperation(dataList);
                    } else {
                        Log.d("UPI", "onActivityResult: " + "Return data is null");
                        ArrayList<String> dataList = new ArrayList<>();
                        dataList.add("nothing");
                        upiPaymentDataOperation(dataList);
                    }
                } else {
                    Log.d("UPI", "onActivityResult: " + "Return data is null"); //when user simply back without payment
                    ArrayList<String> dataList = new ArrayList<>();
                    dataList.add("nothing");
                    upiPaymentDataOperation(dataList);
                }
                break;
        }
    }

    private void upiPaymentDataOperation(ArrayList<String> data) {
        if (isConnectionAvailable(BookingActivity.this)) {
            String str = data.get(0);
            Log.d("UPIPAY", "upiPaymentDataOperation: " + str);
            String paymentCancel = "";
            if (str == null) str = "discard";
            String status = "";
            String approvalRefNo = "";
            String response[] = str.split("&");
            for (int i = 0; i < response.length; i++) {
                String equalStr[] = response[i].split("=");
                if (equalStr.length >= 2) {
                    if (equalStr[0].toLowerCase().equals("Status".toLowerCase())) {
                        status = equalStr[1].toLowerCase();
                    } else if (equalStr[0].toLowerCase().equals("ApprovalRefNo".toLowerCase()) || equalStr[0].toLowerCase().equals("txnRef".toLowerCase())) {
                        approvalRefNo = equalStr[1];
                    }
                } else {
                    paymentCancel = "Payment cancelled by user.";
                }
            }

            if (status.equals("success")) {
                //Code to handle successful transaction here.
                Toast.makeText(BookingActivity.this, "Transaction successful.", Toast.LENGTH_SHORT).show();
                firebaseFirestore.collection("Job").document("DuePayment").collection("UID").document(jobID).update("amount",amount);
                DocumentReference fromPath= firebaseFirestore.collection("Job").document("DuePayment").collection("UID").document(jobID);
                DocumentReference toPath= firebaseFirestore.collection("Job").document("Closed").collection("UID").document(jobID);
                moveFirestoreDocument(fromPath,toPath,state,city,category,subCategory,vendorID,jobID);
                Log.d("UPI", "responseStr: " + approvalRefNo);
            } else if ("Payment cancelled by user.".equals(paymentCancel)) {
                Toast.makeText(BookingActivity.this, "Payment cancelled by user.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(BookingActivity.this, "Transaction failed.Please try again", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(BookingActivity.this, "Internet connection is not available. Please check and try again", Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean isConnectionAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
            if (netInfo != null && netInfo.isConnected()
                    && netInfo.isConnectedOrConnecting()
                    && netInfo.isAvailable()) {
                return true;
            }
        }
        return false;
    }
}