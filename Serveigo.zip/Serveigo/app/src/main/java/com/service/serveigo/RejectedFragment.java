package com.service.serveigo;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class RejectedFragment extends Fragment {

    FirebaseFirestore firebaseFirestore;
    FirebaseUser firebaseUser;
    RecyclerView.Adapter adapter;
    List<ClassBooking> listItems;
    RecyclerView recyclerView;
    ProgressBar progressBar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_rejected, container, false);

        firebaseFirestore= FirebaseFirestore.getInstance();
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        progressBar= view.findViewById(R.id.progressBar);
        recyclerView=view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        listItems= new ArrayList<>();

        adapter=new AdapterBookingList((ArrayList<ClassBooking>) listItems,getContext());

        recyclerView.setAdapter(adapter);

        getResult();
        return view;
    }

    private void getResult(){
        firebaseFirestore.collection("Users").document(firebaseUser.getUid()).collection("Booking").orderBy("date").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    Log.d("xyz", ""+task.getResult());
                    final int[] count = {0};
                    if(task.getResult().size()==0){
                        progressBar.setVisibility(View.GONE);
                    }
                    for (DocumentSnapshot snapshot : task.getResult()) {
                        String status= snapshot.getString("status");
                        firebaseFirestore.collection("Job").document(status).collection("UID").document(snapshot.getId()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if(task!=null) {
                                    final ClassBooking classBooking = task.getResult().toObject(ClassBooking.class);
                                    if(classBooking!=null && classBooking.getStatus().equals("Rejected")) {
                                        Log.d("xyz", classBooking.getVendorName());
                                        classBooking.setJobId(task.getResult().getId());
                                        listItems.add(classBooking);
                                        adapter.notifyDataSetChanged();
                                        progressBar.setVisibility(View.GONE);
                                        count[0]++;
                                    }
                                    firebaseFirestore.collection("Vendor").document(classBooking.getVendorID()).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                            classBooking.vendorImage=task.getResult().getString("vendorImage");
                                            adapter.notifyDataSetChanged();
                                        }
                                    });
                                }
                            }
                        });
                        if(count[0]==0) {
                            //   textViewNoResult.setVisibility(View.VISIBLE);
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                }
                else {
                    progressBar.setVisibility(View.GONE);
                    Log.w("xyz", "Error getting documents.", task.getException());
                }
            }
        });
    }
}