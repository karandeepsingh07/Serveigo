package com.service.serveigo;

public class ClassVendor {
    public String name;
    public String address;

    public String vendorID;

    public String vendorImage;

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getVendorImage() {
        return vendorImage;
    }
}
