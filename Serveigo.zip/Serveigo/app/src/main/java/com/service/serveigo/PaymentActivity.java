
package com.service.serveigo;

import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class PaymentActivity extends AppCompatActivity {
    double total,discount,total_after_discount,percentage;
    String newUser;
    FirebaseFirestore firebaseFirestore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        firebaseFirestore=FirebaseFirestore.getInstance();

     /*   if(newUser.equals("true")){
            discount=0;
        }*/

        getResult();
    }

    private void getResult(){
        firebaseFirestore.collection("Coupons").document("FIRST20").get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                Log.d("xyz",task.toString());
                if(task.isSuccessful()) {
                    Log.d("xyz",task.getResult().get("percentage").toString());
                    percentage= (long) task.getResult().get("percentage");

                    calculate();
                }
                else {
                    Log.w("xyz", "Error getting documents.", task.getException());
                }
            }
        });
    }
    private void calculate(){
        total=109;
        if(percentage!=0) {
            discount = ((total / 100.0f) * percentage);
        }
        total_after_discount = total-discount;
        Log.d("xyz", String.valueOf(total_after_discount));
    }
}