package com.service.serveigo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

public class SupportActivity extends AppCompatActivity {

    Button buttonSupport;
    int REQUEST_PHONE_CALL=1;
    ProgressBar progressBar;
    FirebaseFirestore firebaseFirestore;
    LinearLayout linearLayoutContact;
    String number;
    private ViewPager vp_slider;
    SliderPagerAdapter sliderPagerAdapter;
    ArrayList<String> slider_image_list;
    private TextView dots,dots1,dots2,dots3,dots4;
    int page_position = 0;
    int index=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);


        firebaseFirestore=FirebaseFirestore.getInstance();
        progressBar= findViewById(R.id.progressBar);
        linearLayoutContact= findViewById(R.id.linearLayout_contact);
        buttonSupport= findViewById(R.id.buttonSupport);
        vp_slider = findViewById(R.id.vp_slider);
        slider_image_list = new ArrayList<>();
        sliderPagerAdapter = new SliderPagerAdapter(SupportActivity.this, slider_image_list);
        vp_slider.setAdapter(sliderPagerAdapter);
        dots = findViewById(R.id.dots);
        dots1 = findViewById(R.id.dots1);
        dots2= findViewById(R.id.dots2);
        dots3 = findViewById(R.id.dots3);
        dots4 = findViewById(R.id.dots4);
        dots.setText(Html.fromHtml("&#8226;"));
        dots1.setText(Html.fromHtml("&#8226;"));
        dots2.setText(Html.fromHtml("&#8226;"));
        dots3.setText(Html.fromHtml("&#8226;"));
        dots4.setText(Html.fromHtml("&#8226;"));
        dots.setTextColor(Color.parseColor("#FFFFFF"));
        dots1.setTextColor(Color.parseColor("#FFFFFF"));
        dots2.setTextColor(Color.parseColor("#FFFFFF"));
        dots3.setTextColor(Color.parseColor("#FFFFFF"));
        dots4.setTextColor(Color.parseColor("#FFFFFF"));
        dots.setTextSize(30);
        dots1.setTextSize(30);
        dots2.setTextSize(30);
        dots3.setTextSize(30);
        dots4.setTextSize(30);


        buttonSupport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(SupportActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(SupportActivity.this, new String[]{Manifest.permission.CALL_PHONE},REQUEST_PHONE_CALL);
                }
                else
                {
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
                    startActivity(intent);
                }
            }
        });


        vp_slider.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                addBottomDots(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        getResult();

        final Handler handler = new Handler();

        final Runnable update = new Runnable() {
            public void run() {
                if (page_position == slider_image_list.size()) {
                    page_position = 0;
                } else {
                    page_position = page_position + 1;
                }
                vp_slider.setCurrentItem(page_position, true);
            }
        };

        new Timer().schedule(new TimerTask() {

            @Override
            public void run() {
                handler.post(update);
            }
        }, 100, 5000);
    }

    private void getResult() {
        firebaseFirestore.collection("Admin").document("Contact").get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                number= task.getResult().get("number").toString();
                firebaseFirestore.collection("Admin").document("Ad").collection("List").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()) {
                            for(DocumentSnapshot snapshot1: task.getResult()) {
                                String url=snapshot1.getString("url");
                                slider_image_list.add(url);
                                sliderPagerAdapter.notifyDataSetChanged();
                            }
                            addBottomDots(0);
                            progressBar.setVisibility(View.GONE);
                            linearLayoutContact.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        });
    }

    private void addBottomDots(int currentPage) {
        if(index==0){
            dots4.setTextColor(Color.parseColor("#FFFFFF"));
            dots.setTextColor(Color.parseColor("#000000"));
        }else if(index==1){
            dots.setTextColor(Color.parseColor("#FFFFFF"));
            dots1.setTextColor(Color.parseColor("#000000"));
        }else if(index==2){
            dots1.setTextColor(Color.parseColor("#FFFFFF"));
            dots2.setTextColor(Color.parseColor("#000000"));
        }else if(index==3){
            dots2.setTextColor(Color.parseColor("#FFFFFF"));
            dots3.setTextColor(Color.parseColor("#000000"));
        }else if(index==4){
            dots3.setTextColor(Color.parseColor("#FFFFFF"));
            dots4.setTextColor(Color.parseColor("#000000"));
        }
        index++;
        if(index==5){
            index=0;
        }
    }
}